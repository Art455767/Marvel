package com.example.marvel.models

data class Character (
    val name: String,
    val description: String,
    val thumbnail: Thumbnail,
)