package com.example.marvel.models

data class CharacterResponse(
    val data: CharacterData,
)