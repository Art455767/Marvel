package com.example.marvel.models

data class CharacterData(
    val results: List<Character>,
)