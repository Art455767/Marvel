package com.example.marvel.models

data class Thumbnail (private val path: String, private val extension: String) {
        fun getImageUrl(): String {
            return path
        }
        fun getExtension() = extension
    }
